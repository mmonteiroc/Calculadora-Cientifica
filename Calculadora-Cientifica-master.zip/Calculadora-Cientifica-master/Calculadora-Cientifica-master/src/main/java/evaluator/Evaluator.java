package evaluator;

/**
 * Creado por: mmonteiro
 * miguelmonteiroclaveri@gmail.com
 * github.com/mmonteiroc
 * Paquete evaluator
 * Proyecto Calculadora
 */

import evaluator.Token.Toktype;
import java.util.*;

public class Evaluator {
    /**
     * @param expr Conjunto de tokens que recibimos desordenados
     * @return Resultado de esa operacion matematica
     * <p>
     * Este metodo lo que hacemos es ordenar la expresion que recibimos en anotación
     * "Polaca inversa"
     * <p>
     * Para ello, lo que hacemos es ir token a token leyendo que tipo es,
     * si es un numero, lo añadimos a la lista output, si es un operador lo que hacemos
     * es añadirlo a la pila temporal quitando de la pila los que operadores que tengan menos
     * precedencia y añadiendolos a output, una vez hemos acabado y los tenemos ordenados lo
     * que hacemos es pasarlos al metodo CalcRPN el cual se encarga de retornarnos
     * el resultado de dicha operación matematica.
     */
    public static double calculate(String expr) {
        Token[] tokens = Token.getTokens(expr);
        Deque<Token> pila = new LinkedList<Token>();
        List<Token> output = new ArrayList<Token>();

        int cont = 0;
        for (int i = 0; i < tokens.length; i++) {
            char ttkop=tokens[i].getTkOp();
            Toktype ttype = tokens[i].getTokType();
            if (ttype == Token.Toktype.NUMBER) {
                output.add(tokens[i]);
            } else if (ttkop == ')') {
                Iterator<Token> ItPila = pila.iterator();
                while (ItPila.hasNext()) {
                    Token t = ItPila.next();
                    if (t.getTkOp() == '(') {
                        break;
                    } else {
                        output.add(t);
                        cont++;
                    }
                }
                for (int j = 0; j <= cont; j++) {
                    pila.poll();
                }
                cont = 0;
            } else {
                Iterator<Token> ItPila = pila.iterator();
                if (ttkop == '+' | ttkop == '-') {
                    Token temp;
                    while (ItPila.hasNext()) {
                        temp = ItPila.next();
                        if (temp.getTokType() == Token.Toktype.PAREN) {
                            break;
                        }
                        output.add(temp);
                        cont++;
                    }
                } else if (ttkop == '*' | ttkop == '/') {
                    Token temp;
                    while (ItPila.hasNext()) {
                        temp = ItPila.next();
                        if (temp.getTkOp() == '+' | temp.getTkOp() == '-' | temp.getTkOp() == '(') {
                            break;
                        }
                        output.add(temp);
                        cont++;
                    }
                } else if (tokens[i].getTkOp() == '^') {
                    // Hay que sacar hasta que haya un +, -, *, / o parentesis
                    Token temp;
                    while (ItPila.hasNext()) {
                        temp = ItPila.next();
                        if (temp.getTkOp() == '+' | temp.getTkOp() == '-' | temp.getTkOp() == '(' | temp.getTkOp() == '*' | temp.getTkOp() == '/') {
                            break;
                        }
                        output.add(temp);
                        cont++;
                    }
                } else if (tokens[i].getTkOp() == '_') {
                    // Paramos cuando encontremos cualquier cosa que no es un _
                    Token temp;
                    while (ItPila.hasNext()) {
                        temp = ItPila.next();
                        if (temp.getTkOp() != '_') break;
                        output.add(temp);
                        cont++;
                    }
                }
                for (int j = 0; j < cont; j++) {
                    pila.poll();
                }
                cont = 0;
                pila.push(tokens[i]);
            }
        }
        Iterator<Token> pilaIterator = pila.iterator();
        while (pilaIterator.hasNext()) {
            output.add(pilaIterator.next());
        }
        return Token.calcRPN(output.toArray(new Token[0]));
    }

}