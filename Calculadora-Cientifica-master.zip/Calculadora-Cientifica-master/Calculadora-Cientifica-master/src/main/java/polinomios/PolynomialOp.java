/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polinomios;

/**
 *
 * @author User
 */
public class PolynomialOp {  
    private float[] coeficientes;
    public Polynomial add(Polynomial poligono) {

        float[] mayor;
        float[] menor;
        if (this.coeficientes.length > poligono.coeficientes.length) {
            mayor = this.coeficientes;
            menor = poligono.coeficientes;
        } else {
            mayor = poligono.coeficientes;
            menor = this.coeficientes;
        }

        float[] resultado = new float[mayor.length];
        mayor = invertirArray(mayor);
        menor = invertirArray(menor);
        for (int i = 0; i < resultado.length; i++) {
            if (i >= menor.length) {
                resultado[i] = mayor[i];
            } else {
                resultado[i] = mayor[i] + menor[i];
            }
        }
        resultado = invertirArray(resultado);
        return new Polynomial(resultado);
    }

    public Polynomial mult(Polynomial polinomio) {
        int mayorPotencia1 = this.coeficientes.length - 1, mayorPotencia2 = polinomio.coeficientes.length - 1, longitud = mayorPotencia1 + mayorPotencia2;

        float[] array;
        if (mayorPotencia1 > mayorPotencia2) {
            array = multiplicar(polinomio.coeficientes, this.coeficientes, longitud);
        } else {
            array = multiplicar(this.coeficientes, polinomio.coeficientes, longitud);
        }
        return new Polynomial(array);
    }

    public Polynomial[] div(Polynomial p2) {

        float[] dividendo = copiarArray(this.coeficientes);
        float[] divisor = copiarArray(p2.coeficientes);
        dividendo = invertirArray(dividendo);
        divisor = invertirArray(divisor);

        float[] coeficientesDivision;
        coeficientesDivision = new float[dividendo.length - 1];

        int posicion;
        int x;
        double divi;
        for (int i = dividendo.length - 1; i >= divisor.length - 1; i--) {
            divi = 0;
            x = 1;
            for (int j = divisor.length - 1; j >= 0; j--) {
                posicion = i - j;
                if (j == divisor.length - 1) {
                    if (posicion < 0) {
                        posicion = 0;
                    }
                    coeficientesDivision[posicion] = dividendo[i] / divisor[j];
                    divi = dividendo[i] / divisor[j];
                    dividendo[i] = 0;
                } else {
                    posicion = i - x;
                    if (posicion < 0) {
                        posicion = 0;
                    }
                    dividendo[posicion] += (float) ((divisor[j] * divi) * (-1));
                    x++;
                }
            }
        }
        Polynomial[] polinomios = {new Polynomial(invertirArray(coeficientesDivision)), new Polynomial(invertirArray(dividendo))};
        return polinomios;
    }

    public float[] roots() {
        float[] divisores = new float[0];
        float[] cofi = copiarArray(this.coeficientes);

        boolean PrincipioFin = prueba(cofi);
        float[] resultado = new float[0];

        if (cofi.length == 1) {
            //No hay solucion
            return null;
        } else if (cofi.length == 2) {

            //Primer grado
            resultado = new float[1];
            resultado[0] = (cofi[1] * (-1)) / cofi[0];

        } else if (cofi.length == 3) {

            //Segundo grado
            float a = cofi[0];
            float b = cofi[1];
            float c = cofi[2];
            float discriminante = b * b - 4 * a * c;
            if (discriminante < 0) {
                return null;
            }
            resultado = segundoGrado(cofi);
        } else if (PrincipioFin) {
            //Todo es 0 excepto maximo exponente y termino independiente

            float a = cofi[0];
            float b = cofi[cofi.length - 1] * (-1);

            float discriminante = b / a;
            float indice = cofi.length - 1;
            if (discriminante < 0 && (indice % 2 == 0)) {
                return null;
            } else {
                resultado = calculosPrincipioYfin(cofi, indice, discriminante);
            }

        } else if (cofi.length == 5 && (cofi[1] == 0 && cofi[3] == 0)) {
            //Bicuadratica

            //Segundo grado
            float a = cofi[0];
            float b = cofi[2];
            float c = cofi[4];
            float discriminante = b * b - 4 * a * c;
            if (discriminante < 0) {
                return null;
            }
            float[] cofi1 = new float[3];
            cofi1[0] = cofi[0];
            cofi1[1] = cofi[2];
            cofi1[2] = cofi[4];
            resultado = segundoGrado(cofi1);

            float[] resultado1 = new float[resultado.length * 2];

            for (int i = 0, j = 0; i < resultado.length; i++, j++) {
                resultado1[j] = (float) Math.sqrt(resultado[i]);
                j++;
                resultado1[j] = (float) Math.sqrt(resultado[i]) * (-1);
            }

            resultado = resultado1;

        } else {

            // RUFINI

            float[] c = new float[this.coeficientes.length];
            float[] cIntermedio = new float[c.length];
            float[] cFinal = new float[c.length];

            c = copiarArray(this.coeficientes);

            int ii = 1;
            int divisor = 1;
            float[] ccopia = new float[0];

            boolean prova = false;
            while (ii > 0) {


                float indepe = c[c.length - 1];
                if (comprovar(divisor, divisores)) {
                    if (divisor > 0) {
                        divisor *= (-1);
                    } else {
                        divisor *= (-1);
                        divisor++;
                    }

                    continue;
                }

                if (indepe < 0) indepe *= (-1);
                for (int j = 0; divisor < indepe; divisor += 0) {

                    for (int i = 0; i < c.length; i++) {

                        cFinal[i] += c[i] + cIntermedio[i];

                        if (i + 1 != c.length) {
                            cIntermedio[i + 1] += cFinal[i] * divisor;
                        }
                    }

                    if (cFinal[cFinal.length - 1] == 0) {
                        break;
                    } else {
                        if (divisor > 0) {
                            divisor *= (-1);
                        } else {
                            divisor *= (-1);
                            divisor++;
                        }

                        cFinal = new float[cFinal.length];
                        cIntermedio = new float[cIntermedio.length];
                    }
                }
                float[] copiaDiv = copiarArray(divisores);
                divisores = new float[divisores.length + 1];

                for (int i = 0; i < divisores.length; i++) {
                    if (i >= copiaDiv.length) {
                        divisores[i] = divisor;
                        break;
                    }
                    divisores[i] = copiaDiv[i];
                }

                c = new float[cFinal.length - 1];
                for (int i = 0; i < c.length; i++) {
                    c[i] = cFinal[i];
                }

                cIntermedio = new float[c.length];
                cFinal = new float[c.length];
                ii--;
            }

            this.coeficientes = c;
            float[] otrosResultado = roots();

            int i = 0;

            resultado = new float[divisores.length + otrosResultado.length];
            while (i < divisores.length) {
                resultado[i] = divisores[i];
                i++;
            }
            while (i - divisores.length < otrosResultado.length) {

                resultado[i] = otrosResultado[i - divisores.length];
                i++;
            }

        }
        this.coeficientes = copiaSeguridad;
        resultado = burbuja(resultado);
        return resultado;
    }

    private float[] multiplicar(float[] coef1, float[] coef2, int longitud) {
        float[] resultado = new float[longitud + 1];
        //invertimos los arrays
        coef1 = invertirArray(coef1);
        coef2 = invertirArray(coef2);

        for (int i = 0; i < coef1.length; i++) {
            for (int j = 0; j < coef2.length; j++) {
                resultado[i + j] += coef1[i] * coef2[j];
            }
        }
        resultado = invertirArray(resultado);
        return resultado;
    }

    private void creacionMonomio(String monomio) {
        String aPasar = "";
        boolean simbolo = true; // TRUE POSITIVO ---- FALSE NEGATIVO
        int potencia = 0;
        float coeficiente = 0;

        if (monomio.charAt(0) == '-') {
            // Definimos que el monomio es negativo
            simbolo = false;
        }
        if (monomio.contains("x")) {
            if (monomio.contains("^")) {
                if (monomio.charAt(0) == 'x') {
                    monomio = 1 + monomio;
                } else if (monomio.charAt(0) == '-' && monomio.charAt(1) == 'x') {
                    String monomio2 = "";
                    for (int i = 0; i < monomio.length(); i++) {
                        if (i == 1) {
                            monomio2 = monomio2 + 1;
                        }
                        monomio2 = monomio2 + monomio.charAt(i);
                    }
                }
                int i = monomio.length() - 1;
                while (true) {
                    if (monomio.charAt(i) == '^') {
                        break;
                    }
                    aPasar = monomio.charAt(i) + aPasar;
                    i--;
                }
                potencia = Integer.parseInt(aPasar);
                aPasar = "";
            } else {
                potencia = 1;
            }

            int i = 1;
            if (i + 1 >= monomio.length()) {
                // no hacemos nada
            } else {
                while (true) {
                    if (monomio.charAt(i) == 'x') break;
                    aPasar = aPasar + monomio.charAt(i);
                    if (i + 1 >= monomio.length()) {
                        break;
                    }
                    i++;
                }
            }

            if (aPasar.equals("")) {
                aPasar = "" + 1;
            } else if (aPasar.equals("-")) {
                aPasar = "" + (-1);
            }
            coeficiente = Float.parseFloat(aPasar);
        } else {
            potencia = 0;
            if (monomio.charAt(0) != '-' && monomio.charAt(0) != '+') {
                coeficiente = Float.parseFloat(monomio);
            } else {
                String monomio2 = "";
                for (int i = 1; i < monomio.length(); i++) {
                    monomio2 = monomio2 + monomio.charAt(i);
                }
                coeficiente = Float.parseFloat(monomio2);
            }
        }

        //multiplicacion del simbolo
        if (!simbolo) {
            coeficiente = coeficiente * (-1);
        }
        this.coeficientes[potencia] += coeficiente;
    }

    private int buscarMayorPotencia(String polinomio) {
        int mayorPotencia = 0;
        int potenciaActual = 0;
        String aPasar = "";
        // Encotrnamos la mayor potencia de todo el polinomo
        for (int i = 0; i < polinomio.length(); i++) {
            if (polinomio.charAt(i) == 'x') {
                if (i + 1 >= polinomio.length()) {
                    potenciaActual = 1;
                } else {
                    if (polinomio.charAt(i + 1) == '^') {
                        //Este bucle lo que hace es que te convierte numeros de mas de dos digitos a integer
                        for (int j = i + 2; j < polinomio.length(); j++) {
                            if (polinomio.charAt(j) == '-' || polinomio.charAt(j) == '+') {
                                i += j - i;
                                break;
                            }
                            aPasar += polinomio.charAt(j);
                        }
                        potenciaActual = Integer.parseInt(aPasar);
                    } else {
                        potenciaActual = 1;
                    }
                }
            }
            if (potenciaActual > mayorPotencia) {
                mayorPotencia = potenciaActual;
            }
            aPasar = "";
        }
        return mayorPotencia;
    }

    private float[] copiarArray(float[] array) {
        float[] copia = new float[array.length];
        for (int i = 0; i < array.length; i++) {
            copia[i] = array[i];
        }
        return copia;
    }

    private float[] invertirArray(float[] coeficientes) {

        //te devuelve una copia
        float[] nuevoCoeficiente = copiarArray(coeficientes);

        for (int i = 0, j = nuevoCoeficiente.length - 1; i < j; i++, j--) {

            float swap;
            swap = nuevoCoeficiente[i];
            nuevoCoeficiente[i] = nuevoCoeficiente[j];
            nuevoCoeficiente[j] = swap;

        }
        return nuevoCoeficiente;
    }

    private float[] burbuja(float[] ar) {
        for (int i = ar.length, x = 0; i > x; i--, x++) {

            for (int j = 1; j < i; j++) {
                if (ar[j - 1] > ar[j]) {
                    float Swap1 = ar[j];
                    ar[j] = ar[j - 1];
                    ar[j - 1] = Swap1;
                }
            }
            for (int k = (i - 1); k > x; k--) {
                if (ar[k - 1] > ar[k]) {
                    float swap2 = ar[k];
                    ar[k] = ar[k - 1];
                    ar[k - 1] = swap2;
                }
            }

        }
        return ar;
    }

    private boolean comprovar(float n, float[] divisores) {

        for (int i = 0; i < divisores.length; i++) {
            if (divisores[i] == n) {
                return true;
            }
        }
        return false;

    }

    private float[] segundoGrado(float[] cofi) {
        float a = cofi[0];
        float b = cofi[1];
        float c = cofi[2];
        float[] dev = new float[0];

        float discriminante = b * b - 4 * a * c;
        if (discriminante == 0) {
            float x = (float) (-b + Math.sqrt(discriminante)) / (2 * a);
            dev = new float[1];
            dev[0] = x;
            return dev;
        } else {
            float x1 = (float) (-b + Math.sqrt(discriminante)) / (2 * a);
            float x2 = (float) (-b - Math.sqrt(discriminante)) / (2 * a);
            dev = new float[2];
            dev[0] = x1;
            dev[1] = x2;
        }
        return dev;
    }

    private float[] calculosPrincipioYfin(float[] cofi, float indice, float discriminante) {
        float[] resultado = new float[0];
        if ((cofi.length - 1) % 2 == 0) {
            // DOS SOLUCIONES

            resultado = new float[2];
            resultado[0] = (float) Math.pow(discriminante, 1.0 / indice);
            resultado[1] = (float) Math.pow(discriminante, 1.0 / indice) * (-1);

        } else {
            // UNA SOLUCION
            boolean xx = false;
            resultado = new float[1];
            if (discriminante < 0) {
                discriminante = discriminante * (-1);
                xx = true;
            }
            resultado[0] = (float) Math.pow(discriminante, 1.0 / indice);
            if (xx) {
                resultado[0] = resultado[0] * (-1);
            }
        }
        return resultado;
    }

    private boolean prueba(float[] cofi) {
        int x = 0;
        for (int i = 0; i < cofi.length; i++) {
            if (cofi[i] != 0) x++;
        }

        return x == 2 || (x == 1 && cofi[cofi.length - 1] == 0);
    }
}
