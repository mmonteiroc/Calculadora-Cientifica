package polinomios;

/**
 * Creado por: mmonteiro
 * miguelmonteiroclaveri@gmail.com
 * github.com/mmonteiroc
 * Paquete polinomios
 * Proyecto Calculadora
 */
public class Polynomial {
    //Atributos
    private float[] copiaSeguridad;

    /**
     * Constructor per defecte. Genera un polinomi zero
     */
    public Polynomial() {
        coeficientes = new float[1];
        coeficientes[0] = 0;
    }


    /**
     * @param coeficientes Recibimos un array con todos los coeficientes, lo que haremos primero de
     *                     todo es hacer una copa de ese array ya que asi si el original se modifica
     *                     nosotros seguiremos con el que nos hayan pasado desde el principio
     *                     <p>
     *                     Despues desde la izq iremos mirando los ceros que hay ya que los 0 a la izquierda no
     *                     nos interesan y despues desde el primer numero por la izq que no sea 0 lo copiaremos
     *                     a el array membre coeficientes
     */
    public Polynomial(float[] coeficientes) {
        //Lo que hago aqui es crear un nuevo array para no referenciar al
        // que nos pasan ya que el usuario podria modificar ese array
        //entonces usaremos una copia
        float[] newCoeficientes = new float[coeficientes.length];
        for (int i = 0; i < coeficientes.length; i++) {
            newCoeficientes[i] = coeficientes[i];
        }
        int x = 0;
        for (int i = 0; i < newCoeficientes.length; i++) {
            if (newCoeficientes[i] == 0) {
                x++;
            } else {
                break;
            }
        }
        if (x == newCoeficientes.length) {

            this.coeficientes = new float[1];
            this.coeficientes[0] = 0;
        } else {
            this.coeficientes = new float[newCoeficientes.length - x];
            for (int i = 0, j = x; i < this.coeficientes.length; i++, j++) {
                this.coeficientes[i] = newCoeficientes[j];
            }
        }

        this.copiaSeguridad = copiarArray(this.coeficientes);
    }

    /**
     * @param stringPolinomio Recibimos un polinomio en formato de String (2x^3 - 4 + 5x^2 + 32)
     *                        <p>
     *                        Esta funcion va leyendo el string monomio a monomio y lo que hace es ir
     *                        pasando esos monomios a otra funcion externa la cual se encargara de mirar la potencia de ese monomio
     *                        y añadirlo al array de coeficientes donde le toca
     */
    public Polynomial(String stringPolinomio) {

        if (stringPolinomio.length() == 1 || (stringPolinomio.length() == 2 && (stringPolinomio.charAt(0) == '-' || stringPolinomio.charAt(0) == '+'))) {
            this.coeficientes = new float[1];
            if (stringPolinomio.charAt(0) == 'x') {
                this.coeficientes = new float[2];
                this.coeficientes[0] = 1;
                this.coeficientes[1] = 0;

            } else {

                this.coeficientes[0] = Float.parseFloat(stringPolinomio);
            }
            return;
        }
        if (stringPolinomio.charAt(0) != 'x' && stringPolinomio.charAt(0) != '-' && stringPolinomio.charAt(0) != '+') {
            stringPolinomio = "+" + stringPolinomio;
        }

        // Rutina que elimina espacios
        StringBuilder polinomio = new StringBuilder();
        for (int i = 0; i < stringPolinomio.length(); i++) {
            if (stringPolinomio.charAt(i) != ' ') {
                polinomio.append(stringPolinomio.charAt(i));
            }
        }

        int mayorPotencia = buscarMayorPotencia(polinomio.toString());

        // Creamos el array del objeto con la longitud que le toca
        this.coeficientes = new float[mayorPotencia + 1];

        // Llamamos a la funcion que añade cada
        // monomio en la posicion de coeficientes que le pertañe
        String monomio = "";
        for (int i = 0; i < polinomio.length(); i++) {
            if ((polinomio.charAt(i) == '-' || polinomio.charAt(i) == '+') && i > 0) {
                creacionMonomio(monomio);
                monomio = "";
            }
            monomio = monomio + polinomio.charAt(i);
            if (i + 1 >= polinomio.length()) {
                creacionMonomio(monomio);
                monomio = "";
            }
        }

        invertirArray();


        if (this.coeficientes.length > 1) {
            //Comprovacion fallo 0 a la izq
            int comp = 0;
            while (true) {
                if (this.coeficientes[comp] == 0) {
                    // Si es todo 0 lo que hacemos es restaurar
                    //  el array y hacer que sea de longitud 1 con un 0
                    if (comp + 1 == this.coeficientes.length) {
                        this.coeficientes = new float[1];
                        this.coeficientes[0] = 0;
                        return;
                    }

                    comp++;
                    continue;
                } else {
                    break;
                }
            }

            // Si hay algun 0 a la izq lo que
            // hacemos es quitar esos 0 de la izquierda
            if (comp != 0) {
                int longi = this.coeficientes.length;
                float[] copia = new float[longi];

                for (int i = 0; i < longi; i++) {
                    copia[i] = this.coeficientes[i];
                }
                this.coeficientes = new float[longi - comp];
                for (int i = 0; i < this.coeficientes.length; i++) {
                    this.coeficientes[i] = copia[comp];
                    comp++;
                }
            }
        }
        this.copiaSeguridad = copiarArray(this.coeficientes);
    }

 @Override
    public boolean equals(Object objeto) {
        Polynomial p1 = (Polynomial) objeto;
        if (p1.coeficientes.length != this.coeficientes.length) return false;
        for (int i = 0; i < this.coeficientes.length; i++) {
            if (this.coeficientes[i] != p1.coeficientes[i]) {
                return false;
            }
        }
        return true;
    }

        @Override
    public String toString() {
        if (coeficientes.length == 1 && coeficientes[0] == 0) {
            return "0";
        }
        String devolver = "";
        float[] coeficientesInvertidos = invertirArray(this.coeficientes);
        String simbolo = "";
        int potencia = 0;
        int cof1 = 0;
        float cof2 = 0;

        for (int i = 0; i < coeficientesInvertidos.length; i++) {
            cof1 = (int) coeficientesInvertidos[i];
            cof2 = coeficientesInvertidos[i];
            if (coeficientesInvertidos[i] == 0) {
                continue;
            }
            if (coeficientesInvertidos[i] >= 0) {
                simbolo = "+";
            } else {
                simbolo = "-";
                cof1 = (int) coeficientesInvertidos[i] * (-1);
                cof2 = coeficientesInvertidos[i] * (-1);
            }

            if (cof1 == cof2) {// SE USARA NUMEROS ENTEROS
                if (i == 0) {
                    // Posicion 0 ira sin X

                    devolver = cof1 + devolver;
                } else if (i == 1) {
                    // Posicion 1 ira con X sin capellan
                    if (cof1 == 1) {
                        devolver = "x" + devolver;
                    } else {
                        devolver = cof1 + "x" + devolver;
                    }
                } else {
                    //Todas las demas posiciones iran con X y con ^ donde la potencia sera la I
                    if (cof1 == 1 || cof1 == -1) {
                        devolver = "x^" + i + devolver;
                    } else {
                        devolver = cof1 + "x^" + i + devolver;
                    }
                }
            } else {// SE USARA NUMEROS DECIMALES
                if (i == 0) {
                    // Posicion 0 ira sin X
                    devolver = coeficientesInvertidos[i] + devolver;
                } else if (i == 1) {
                    // Posicion 1 ira con X sin capellan
                    if (coeficientesInvertidos[i] == 1) {
                        devolver = "x" + devolver;

                    } else {
                        devolver = coeficientesInvertidos[i] + "x" + devolver;
                    }
                } else {
                    //Todas las demas posiciones iran con X y con ^ donde la potencia sera la I
                    if (cof1 == 1) {
                        devolver = "x^" + i + devolver;
                    } else {
                        float num = coeficientesInvertidos[i];
                        if (simbolo.equals("-")) {
                            num = num * (-1);
                        }
                        devolver = num + "x^" + i + devolver;
                    }
                }
            }

            if (i + 1 != coeficientesInvertidos.length) {
                devolver = " " + simbolo + " " + devolver;
            } else if (simbolo.equals("-")) {
                devolver = simbolo + "" + devolver;
            }
        }
        return devolver;
    }

    private void invertirArray() {
        for (int i = 0, j = this.coeficientes.length - 1; i < j; i++, j--) {
            float swap;
            swap = this.coeficientes[i];
            this.coeficientes[i] = this.coeficientes[j];
            this.coeficientes[j] = swap;
        }
    }
}